package com.example.routes           // 👈 mismo paquete que los demás routes

import com.example.repository.UserRepository
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.userRoutes(userRepo: UserRepository) {

    /**  lista de usuarios (protector opcional) **/
    authenticate(optional = true) {          // pon 'optional=true' si quieres que funcione con o sin token
        get("/users") {
            call.respond(userRepo.getAllUsers())
        }
    }
}
