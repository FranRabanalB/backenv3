package com.example.repository

import at.favre.lib.crypto.bcrypt.BCrypt
import com.example.models.Users       // tu objeto-tabla
import com.example.models.Users.DTO   // tu DTO serializable
import com.example.models.Users.toDTO // helper de mapeo
import kotlinx.coroutines.Dispatchers
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.experimental.newSuspendedTransaction
import org.jetbrains.exposed.sql.insertAndGetId
import org.jetbrains.exposed.sql.selectAll
import java.util.*

/** Repository basado en Exposed + coroutines */
class UserRepository {

    /* Helper para ejecutar el bloque dentro de una transacción suspendida */
    private suspend fun <T> dbQuery(block: () -> T): T =
        newSuspendedTransaction(Dispatchers.IO) { block() }

    /* ---------- 1) Búsqueda por e-mail ---------- */
    suspend fun findByEmail(email: String): Users.DTO? = dbQuery {
        Users                       // objeto-tabla
            .select { Users.email eq email }   // ← lambda now recognised
            .singleOrNull()                    // devuelve 0 o 1 fila
            ?.toDTO()
    }


    /* ---------- 2) Validar credenciales ---------- */
    suspend fun validateCredentials(email: String, password: String): DTO? = dbQuery {
        Users.selectAll()
            .where { Users.email eq email }
            .singleOrNull()
            ?.let { row ->
                val hashInDb = row[Users.passwordHash]
                val verified = BCrypt.verifyer()
                    .verify(password.toCharArray(), hashInDb)
                    .verified
                if (verified) row.toDTO() else null
            }
    }

    /* ---------- 3) Registrar nuevo usuario ---------- */
    suspend fun registerUser(
        username: String,
        email: String,
        password: String,
        roles: List<String> = listOf("user")
    ): DTO? = dbQuery {
        // Evitar e-mails duplicados
        if (Users.select { Users.email eq email }.empty()) {
            val id = Users.insertAndGetId {
                it[Users.username]     = username
                it[Users.email]        = email
                it[Users.passwordHash] = BCrypt.withDefaults()
                    .hashToString(12, password.toCharArray())
                it[Users.roles]        = roles.joinToString(",")
            }.value
            // Devuelve la fila recién insertada como DTO
            Users.select { Users.id eq id }.single().toDTO()
        } else {
            null                // ya existe un usuario con ese e-mail
        }
    }

    /* ---------- 4) Obtener todos los usuarios ---------- */
    suspend fun getAllUsers(): List<DTO> = dbQuery {
        Users.selectAll().map { it.toDTO() }
    }

    /* ---------- (opcional) Buscar por ID ---------- */
    suspend fun findById(id: UUID): DTO? = dbQuery {
        Users.select { Users.id eq id }
            .singleOrNull()
            ?.toDTO()
    }
}
