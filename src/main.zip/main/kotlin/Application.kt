package com.example

import com.example.database.DatabaseFactory
import com.example.repository.UserRepository            // ✔
import com.example.routes.JwtConfig
import com.example.plugins.configureRouting
import com.example.plugins.configureSerialization
import io.ktor.server.application.*

fun main(args: Array<String>) {
    io.ktor.server.netty.EngineMain.main(args)
}

fun Application.module() {

    /* 1️⃣ Conectar Base de Datos y sembrar admin */
    DatabaseFactory.init(environment.config)

    /* 2️⃣ Configuración JWT */
    val jwtCfg = JwtConfig(
        issuer   = environment.config.property("ktor.jwt.issuer").getString(),
        audience = environment.config.property("ktor.jwt.audience").getString(),
        secret   = environment.config.property("ktor.jwt.secret").getString()
    )

    /* 3️⃣ Instancia de repositorio */
    val userRepo = UserRepository()                     // ← FALTABA ESTO

    /* 4️⃣ Otros plugins */
    configureSerialization()
    // configureSecurity()   // quítalo o añádelo solo si existe

    /* 5️⃣ Rutas con dependencias */
    configureRouting(userRepo, jwtCfg)
}
